# Contributing to phpSysInfo 
First time contributing to phpSysInfo? Read our [Code of Conduct](https://github.com/phpsysinfo/phpsysinfo/blob/master/CODE_OF_CONDUCT.md).

### Propose a feature

If you have a great idea or want to help out, just create a pull request with your change proposal
in the [phpSysInfo](https://github.com/phpsysinfo/phpsysinfo) repository.
